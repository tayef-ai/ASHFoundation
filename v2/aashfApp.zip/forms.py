from django import forms
from .models import Registration, Contact
from django_recaptcha.fields import ReCaptchaField
from django_recaptcha.widgets import ReCaptchaV2Checkbox


class EventRegistrationForm(forms.ModelForm):
    captcha = ReCaptchaField(widget=ReCaptchaV2Checkbox)
    class Meta:
        model = Registration
        fields = ['name', 'address', 'email', 'mobile', 'image', 'captcha']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder':'Name'}),
            # 'father_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': "Father's Name"}),
            'address': forms.Textarea(attrs={'class':'form-control', 'placeholder': 'Enter Address'}),
            'email': forms.EmailInput(attrs={'class':'form-control', 'placeholder': 'Email'}),
            'mobile': forms.TextInput(attrs={'class': 'form-control', 'placeholder':'01...'}),
            'image': forms.ClearableFileInput(attrs={'class': 'form-control-file'})
        }

class ContactForm(forms.ModelForm):
    captcha = ReCaptchaField(widget=ReCaptchaV2Checkbox)
    class Meta:
        model = Contact
        fields = ['message', 'name', 'email', 'subject', 'captcha']
        
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder':'Enter Your Name'}),
            'message': forms.Textarea(attrs={'class':'form-control', 'placeholder': 'Write Message'}),
            'email': forms.EmailInput(attrs={'class':'form-control', 'placeholder': 'Enter Your Email'}),
            'subject': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Subject'})
        }