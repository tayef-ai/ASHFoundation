from django.shortcuts import render, redirect
from .models import *
from .forms import EventRegistrationForm, ContactForm
from django.contrib import messages
from django.http import HttpResponseRedirect
import random
from itertools import chain
from django.db.models import Q
from django.utils import timezone
from django.conf import settings
from django.template.loader import render_to_string
from django.http import JsonResponse
from django.core.cache.backends.base import DEFAULT_TIMEOUT
# from django.views.decorators.cache import cache_page
from django.core.cache import cache
from django.core.paginator import Paginator
# from django.contrib.gis.geoip2 import GeoIP2

# CACHE_TTL = getattr(settings, 'CACHE_TTL', DEFAULT_TIMEOUT)

def homeview(request):
    # user_ip = request.META.get('REMOTE_ADDR', '127.0.0.1') 
    # g = GeoIP2()
    # if user_ip == '127.0.0.1':
    #     country = 'Bangladesh'
    # else:
    #     country = g.country_name(user_ip)
    # if country == 'Bangladesh':
    country = request.GET.get('country', 'Bangladesh')
    r = Region.objects.get(name=country)
    query = Setting.objects.get(region=r)
    today = timezone.now().date()
    events = None
    activities = None
    videos = None
    volunteers = None
    if not activities:
        activities = Activiti.objects.all().order_by('-id')[:3]
    if not events:
        events = Event.objects.filter(
            Q(open_date__lte=today, close_date__gte=today) | Q(open_date__gt=today)
        ).order_by('open_date')[:3]

        if events.count() < 3:
            additional_closed_events = Event.objects.filter(
                close_date__lt=today
            ).order_by('-close_date')[:3 - events.count()]
            events = list(events) + list(additional_closed_events)

        # Cache the events result for 10 minutes (600 seconds)
        # cache.set('home_events', events, timeout=CACHE_TTL)

    if not videos:
        videos = Video.objects.all().order_by('created_at')[:6]
        # Cache the videos result for 10 minutes (600 seconds)
        # cache.set('home_videos', videos, timeout=CACHE_TTL)

    if not volunteers:
        volunteers = Volunteer.objects.all()[:3]
        # Cache the volunteers result for 10 minutes (600 seconds)
        # cache.set('home_volunteers', volunteers, timeout=CACHE_TTL)

    # Render the response with cached or freshly fetched data
    return render(request, 'home.html', {'events': events, 'videos': videos, 'volteers': volunteers, 'setting': query, 'activities':activities})

def eventview(request):
    today = timezone.now().date()
    events = None
    banner_image = None
    if not events or not banner_image:
        # If the cache is empty, query the database
        if not events:
            ongoing_events = Event.objects.filter(open_date__lte=today, close_date__gte=today)
            upcoming_events = Event.objects.filter(open_date__gt=today)
            closed_events = Event.objects.filter(close_date__lt=today)

            # Combine the querysets
            events = list(chain(ongoing_events, upcoming_events, closed_events))
            paginator = Paginator(events, 6)
            page_number = request.GET.get('page')
            page_obj = paginator.get_page(page_number)
        if events:
            # Get the last event and its banner image
           
            banner_image = events[0].event_image.filter(is_banner=True).first()
        else:
            banner_image = None
        # Cache the events and banner image
        # cache.set('events_cache', events, timeout=CACHE_TTL)
        # cache.set('banner_image_cache', banner_image, timeout=CACHE_TTL)

    context = {
        'events': page_obj,
        'banner': banner_image
    }
    return render(request, 'event.html', context)

def event_detail(request, id):
    query = Event.objects.get(pk=id)
    banner_image = query.event_image.filter(is_banner=True).first()
    # print("==================", banner_image) 
    return render(request, 'event_details.html', {'query': query, 'banner': banner_image})

def event_register(request, id):
    query = Event.objects.get(pk=id)
    banner_image = query.event_image.filter(is_banner=True).first()
    
    if request.method == 'GET':
        form = EventRegistrationForm()
        return render(request, 'event_register.html', {'query': query, 'form': form, 'banner': banner_image})
    
    if request.method == 'POST':
        form = EventRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            form = form.save(commit=False)
            form.event = query
            form.save()
            # messages.success(request, "Your form has been submitted successfully!")
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'status': 'success', 'message': "Your form has been submitted successfully!"})
            return redirect('event_register', id=id)
        else:
            error_message = "There was an error submitting the form. Please check the details and try again."
            messages.error(request, error_message)
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'status': 'error', 'message': error_message})
    return render(request, 'event_register.html', {'query': query, 'form': form, 'banner': banner_image})
            
def gallery(request):
    query = None
    banner_image = None
    if not query:
        query = Image.objects.all().order_by('-id')
        paginator = Paginator(query, 6)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        # cache.set('all_images', query)
    if not banner_image:
        banner_image = Image.objects.filter(is_banner=True).first()
        # cache.set('banner_image', banner_image)
    return render(request, 'gallery.html', {'banner': banner_image, 'query': page_obj})

def contactview(request):
    query = None
    # map_iframe = cache.get('google_map_iframe')
    map_iframe = None
    if not query:
        query = Image.objects.all().order_by('-id')
        # cache.set('images', query, timeout=CACHE_TTL)
    if not map_iframe:
        # If not cached, render the iframe HTML
        map_iframe = """
            <div class="d-none d-sm-block mb-5 pb-4">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1844.741367879672!2d91.85352633936633!3d22.373152038879955!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30acd942e1dd4e4b%3A0x185a64b7b8defff0!2sAlhaj%20Shamsul%20Hoque%20Foundation%20(ASHF)!5e0!3m2!1sen!2sbd!4v1728715541149!5m2!1sen!2sbd" width="1000" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        """
        # Store the iframe in the cache
        # cache.set('google_map_iframe', map_iframe, timeout=CACHE_TTL)
    form = ContactForm()
    banner_image = Image.objects.filter(is_banner=True).first()
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            # messages.success(request, "Your form has been submitted successfully!")
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'status': 'success', 'message': "Your form has been submitted successfully!"})
            return redirect('contact')
        else:
            error_message = "There was an error submitting the form. Please check the details and try again."
            messages.error(request, error_message)
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'status': 'error', 'message': error_message})

    return render(request, 'contact.html', {'banner': banner_image, 'query': query, 'map': map_iframe, 'form': form})

def projectview(request):
    query = Project.objects.all().order_by('-id')
    paginator = Paginator(query, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'project.html', {'query': page_obj})

def project_detail(request, id):
    query = Project.objects.get(pk=id)
    return render(request, 'project_details.html', {'query': query})

def activityview(request):
    query = Activiti.objects.all().order_by('-id')
    paginator = Paginator(query, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'activity.html', {'query': page_obj})

def activity_detail(request, id):
    query = Activiti.objects.get(pk=id)
    return render(request, 'activity_detail.html', {'query': query})

def campaignview(request):
    query = Campaign.objects.all().order_by('-id')
    paginator = Paginator(query, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'campaign.html', {'query': page_obj})

def campaign_detail(request, id):
    query = Campaign.objects.get(pk=id)
    return render(request, 'campaign_details.html', {'query': query})

def rohingyaview(request):
    query = Rohingya.objects.all().order_by('-id')
    paginator = Paginator(query, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'rohingya.html', {'query': page_obj})

def rohingya_detail(request, id):
    query = Rohingya.objects.get(pk=id)
    return render(request, 'rohingya_details.html', {'query': query})

def legalview(request):
    query = LegalDocument.objects.all().order_by('-id')
    paginator = Paginator(query, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'legal.html', {'query': page_obj})

def legal_detail(request, id):
    query = LegalDocument.objects.get(pk=id)
    return render(request, 'legal_details.html', {'query': query})

def blogview(request):
    query = Blog.objects.all().order_by('-id')
    paginator = Paginator(query, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'blog.html', {'query': page_obj})

def blog_detail(request, id):
    query = Blog.objects.get(pk=id)
    return render(request, 'blog_details.html', {'query': query})

def gbview(request):
    query = GoverningBodie.objects.all()
    return render(request, 'gb.html', {'query': query})

def apview(request):
    query = Advisor.objects.all()
    return render(request, 'ap.html', {'query': query})

def volunteerview(request):
    query = Volunteer.objects.all().order_by('-id')
    paginator = Paginator(query, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'volunteer.html', {'query': page_obj})

def awardview(request):
    query = Awards.objects.all().order_by('-id')
    return render(request, 'awards.html', {'query': query})

def missionview(request):
    query = Mission.objects.all()[:3]
    return render(request, 'mission.html', {'query': query})

def search(request):
    query = request.GET.get('q')
    
    results = {
        'events': Event.objects.filter(
            models.Q(e_name__icontains=query) | models.Q(e_details__icontains=query)
        ) if query else Event.objects.none(),
        'projects': Project.objects.filter(
            models.Q(p_name__icontains=query) | models.Q(p_details__icontains=query)
        ) if query else Project.objects.none(),
        'blogs': Blog.objects.filter(
            models.Q(b_name__icontains=query) | models.Q(b_details__icontains=query)
        ) if query else Blog.objects.none(),
        'volunteers': Volunteer.objects.filter(
            models.Q(name__icontains=query) | models.Q(address__icontains=query) | models.Q(role__icontains=query)
        ) if query else Volunteer.objects.none(),
        'campaigns': Campaign.objects.filter(
            models.Q(c_name__icontains=query) | models.Q(c_details__icontains=query)
        ) if query else Campaign.objects.none(),
        'rohingyas': Rohingya.objects.filter(
            models.Q(r_name__icontains=query) | models.Q(r_details__icontains=query)
        ) if query else Rohingya.objects.none(),
        'legal_documents': LegalDocument.objects.filter(
            models.Q(l_title__icontains=query)
        ) if query else LegalDocument.objects.none(),
    }
    
    return render(request, 'search_results.html', {'query': query, 'results': results})

